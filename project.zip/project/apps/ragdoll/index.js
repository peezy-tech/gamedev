export default (world, app, fetch, props, setTimeout) => {
  if (world.isServer) {
    app.on('toggleRagdoll', ({ playerId, enable, force, opts }) => {
      const player = world.getPlayer(playerId)
      if (!player) return
      if (enable) {
        player.ragdoll(true, force ? new Vector3(...force) : undefined, opts)
      } else {
        player.ragdoll(false)
      }
    })
  }

  if (world.isClient) {
    let active = null
    const player = world.getPlayer()
    let mode = 'server'

    const tests = [
      { label: 'Sniper Hit',      force: [8, 2, -18], opts: { stiffness: 0.6, damping: 0.25, duration: 1.4, muscleFadeDuration: 0.2 } },
      { label: 'Uppercut',        force: [0, 16, -2], opts: { gravity: 1.2, bounce: 0.1, flailDuration: 1.8 } },
      { label: 'Slip & Recover',  force: [2, 1, 0],   opts: { stiffness: 2.2, damping: 2.8, duration: 1.1, flailDuration: 0.7 } },
      { label: 'Ice Physics',     force: [3, 2, -4],  opts: { damping: 0.02, bounce: 0.25, gravity: 0.9, flailDuration: 3.8 } },
      { label: 'Moon Bounce',     force: [0, 6, 0],   opts: { gravity: 0.18, bounce: 0.92, damping: 0.08, flailDuration: 5 } },
      { label: 'Anvil Drop',      force: [0, 1, 0],   opts: { gravity: 4.2, damping: 0.6, stiffness: 1.4, duration: 1.6 } },
      { label: 'Wet Noodle',      force: [1, 3, -1],  opts: { stiffness: 0.08, damping: 0.04, flailDuration: 4.5, muscleFadeDuration: 1.2 } },
      { label: 'Statue Shatter',  force: [0, 5, -3],  opts: { stiffness: 4.5, damping: 4.0, duration: 0.9, muscleFadeDuration: 0.1 } },
      { label: 'Explosion Left',  force: [-14, 8, 0], opts: { gravity: 1.1, damping: 0.2, bounce: 0.35, flailDuration: 2.4 } },
      { label: 'Black Hole',      force: [0, -2, 0],  opts: { gravity: 7, damping: 1.6, stiffness: 0.35, duration: 2.2 } },
    ]

    const expandedPanelHeight = (tests.length + 3) * 34 + 24
    const collapsedPanelHeight = 44

    const panel = app.create('ui', {
      space: 'screen',
      pivot: 'top-right',
      position: [1, 0, 0],
      offset: [-12, 12, 0],
      width: 170,
      height: expandedPanelHeight,
      backgroundColor: 'rgba(15, 15, 15, 0.75)',
      borderRadius: 10,
      borderWidth: 1,
      borderColor: 'rgba(255, 255, 255, 0.12)',
      padding: 8,
      gap: 4,
      pointerEvents: true,
    })

    let collapsed = false
    const rows = []

    const headerRow = app.create('uiview', {
      width: 154,
      height: 28,
      backgroundColor: 'rgba(255, 255, 255, 0.08)',
      borderRadius: 6,
      borderWidth: 1,
      borderColor: 'rgba(255, 255, 255, 0.14)',
      justifyContent: 'center',
      alignItems: 'center',
    })
    const title = app.create('uitext', {
      value: 'Ragdoll Tests ▼',
      fontSize: 13,
      fontWeight: 600,
      color: 'rgba(255, 255, 255, 0.85)',
      textAlign: 'center',
    })
    headerRow.add(title)
    panel.add(headerRow)
    const buttons = []

    const modeRow = app.create('uiview', {
      width: 154,
      height: 28,
      backgroundColor: 'rgba(255, 255, 255, 0.08)',
      borderRadius: 6,
      borderWidth: 1,
      borderColor: 'rgba(255, 255, 255, 0.12)',
      justifyContent: 'center',
      alignItems: 'center',
    })
    const modeLabel = app.create('uitext', {
      value: 'Mode: Server Sync',
      fontSize: 12,
      color: 'rgba(255, 255, 255, 0.9)',
      textAlign: 'center',
    })
    modeRow.add(modeLabel)
    modeRow.onPointerDown = () => {
      mode = mode === 'server' ? 'client' : 'server'
      modeLabel.value = mode === 'server' ? 'Mode: Server Sync' : 'Mode: Client Local'
    }
    panel.add(modeRow)
    rows.push(modeRow)

    function applyRagdoll(enable, force, opts) {
      if (mode === 'server') {
        app.send('toggleRagdoll', { playerId: player.id, enable, force, opts })
      } else {
        player.ragdoll(enable, force ? new Vector3(...force) : undefined, opts)
      }
    }

    const resetRow = app.create('uiview', {
      width: 154,
      height: 28,
      backgroundColor: 'rgba(255, 120, 120, 0.12)',
      borderRadius: 6,
      borderWidth: 1,
      borderColor: 'rgba(255, 120, 120, 0.35)',
      justifyContent: 'center',
      alignItems: 'center',
    })
    const resetLabel = app.create('uitext', {
      value: 'Reset (ragdoll: false)',
      fontSize: 12,
      color: 'rgba(255, 210, 210, 0.95)',
      textAlign: 'center',
    })
    resetRow.add(resetLabel)
    resetRow.onPointerDown = () => {
      applyRagdoll(false)
      active = null
      updateButtons()
    }
    panel.add(resetRow)
    rows.push(resetRow)

    for (const test of tests) {
      const row = app.create('uiview', {
        width: 154,
        height: 28,
        backgroundColor: 'rgba(255, 255, 255, 0.06)',
        borderRadius: 6,
        borderWidth: 1,
        borderColor: 'rgba(255, 255, 255, 0.08)',
        justifyContent: 'center',
        alignItems: 'center',
      })

      const label = app.create('uitext', {
        value: test.label,
        fontSize: 12,
        color: 'rgba(255, 255, 255, 0.8)',
        textAlign: 'center',
      })

      row.add(label)

      row.onPointerEnter = () => {
        if (active !== test.label) {
          row.backgroundColor = 'rgba(255, 255, 255, 0.15)'
          row.borderColor = 'rgba(255, 255, 255, 0.25)'
        }
      }

      row.onPointerLeave = () => {
        if (active !== test.label) {
          row.backgroundColor = 'rgba(255, 255, 255, 0.06)'
          row.borderColor = 'rgba(255, 255, 255, 0.08)'
        }
      }

      row.onPointerDown = () => {
        console.log('pointer down', test.label)
        if (active === test.label) {
          applyRagdoll(false)
          active = null
        } else {
          if (active) {
            applyRagdoll(false)
          }
          active = test.label
          applyRagdoll(true, test.force, test.opts)
        }
        updateButtons()
      }

      panel.add(row)
      rows.push(row)
      buttons.push({ row, label, test })
    }

    function updateMenuState() {
      for (const row of rows) {
        row.display = collapsed ? 'none' : 'flex'
      }
      panel.height = collapsed ? collapsedPanelHeight : expandedPanelHeight
      title.value = collapsed ? 'Ragdoll Tests ▶' : 'Ragdoll Tests ▼'
    }

    headerRow.onPointerDown = () => {
      collapsed = !collapsed
      updateMenuState()
    }

    updateMenuState()

    function updateButtons() {
      for (const btn of buttons) {
        if (active === btn.test.label) {
          btn.row.backgroundColor = 'rgba(100, 180, 255, 0.35)'
          btn.row.borderColor = 'rgba(100, 180, 255, 0.5)'
          btn.label.color = '#ffffff'
        } else {
          btn.row.backgroundColor = 'rgba(255, 255, 255, 0.06)'
          btn.row.borderColor = 'rgba(255, 255, 255, 0.08)'
          btn.label.color = 'rgba(255, 255, 255, 0.8)'
        }
      }
    }

    app.add(panel)
  }
}
